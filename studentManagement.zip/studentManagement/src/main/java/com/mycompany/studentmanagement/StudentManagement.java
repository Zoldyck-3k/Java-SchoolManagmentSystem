/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.studentmanagement;

/**
 *
 * @author RT Nexgen
 */
public class StudentManagement {

    public static void main(String[] args) {
      new NewJFrame().setVisible(true );  
     
     
    }
}
